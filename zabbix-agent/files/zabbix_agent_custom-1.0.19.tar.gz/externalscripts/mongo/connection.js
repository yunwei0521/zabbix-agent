var item=db.serverStatus().connections;
printjson (item);
